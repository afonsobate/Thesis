from config import KAFKA_SERVER
import pysftp
from kafka import KafkaConsumer
import pickle
import time

def main():
    while True:
        try:
            consumer = KafkaConsumer('sftp', value_deserializer=lambda v: pickle.loads(v), bootstrap_servers=[KAFKA_SERVER], group_id='module1', auto_offset_reset='earliest',)
            print("Connected to Kafka broker")
            break
        except:
            time.sleep(3)
            pass

    # Define the connection parameters
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None  # Disable host key checking (for local network use)
    hostname = "192.168.1.76"
    username = "afonsob"
    password = "300798ab"
    port = 22

    try:
        sftp = pysftp.Connection(host=hostname, username=username, password=password, cnopts=cnopts, port=port)
    except Exception as e:
        print(f"Error: {e}")

    remote_path = "/mnt/c/UserData/z004raud/Documents/Tese/smart-retail-example/V1/output/state_store"
    local_path = "/home/bate/smart-retail-example/V1/ssh-test"

    for msg in consumer:
        frame_count = int(msg.value['frame_count'])
        sent = 0
        while True:
            try:
                # Upload a file from Laptop A to Laptop B
                if (sent == 0):
                    sftp.put(f"{remote_path}/{frame_count}.torchscript", f"{local_path}/{frame_count}.torchscript")
                    sent+=1
                if (sent > 0):
                    sftp.put(f"{remote_path}/predictor{frame_count}.pkl", f"{local_path}/predictor{frame_count}.pkl")
                print("Sent files")
                break
            except Exception as e:
                print("Trying to send file again...")
    consumer.commit()
    sftp.close()

if __name__ == "__main__":
    main()