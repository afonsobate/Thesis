# Smart Retail Example

Testbed for Smart Retail applications.

## Next steps

Task is to build up the next scenario:

 - 2.5D Map, maybe use an orthogonal camera for simplification
 - setup a room with 4 aisles
 - Each aisle is associated with a product. For simplicity visiting an aisle is equivalent to buying a product
 - When a customer exits it is equivalent to the checkout
 - For the sake of simplicity, one person is inside the store at a time

## Datasets to checkout

 - Person identification datasets
    - Market-1501: https://paperswithcode.com/dataset/market-1501
    - CUHK03: https://paperswithcode.com/dataset/cuhk03
 - Person face detection dataset:
    - Libfacedetection: https://github.com/ShiqiYu/libfacedetection
 - Suspect behaviour datasets
    - UBI-Fights: http://socia-lab.di.ubi.pt/EventDetection/
    - UCF-Crime : https://www.crcv.ucf.edu/research/real-world-anomaly-detection-in-surveillance-videos/
 - Person hand keypoints and object manipulation dataset:
    - CMU PanopticStudio Database: http://domedb.perception.cs.cmu.edu/handdb.html
 - Person counter dataset:
    - PCDS: https://github.com/shijieS/people-counting-dataset

