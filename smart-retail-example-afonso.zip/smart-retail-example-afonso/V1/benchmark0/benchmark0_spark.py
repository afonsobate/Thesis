from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import shutil
import os
import time

checkpointLocation = "/home/bate/smart-retail-example/V1/benchmark0/spark/output/check"
checkpointLocationAux = "/home/bate/smart-retail-example/V1/benchmark0/spark/aux/check"
checkpointLocationTest = "/home/bate/smart-retail-example/V1/benchmark0/spark/test/check"
outputPath = "/home/bate/smart-retail-example/V1/benchmark0/spark/output"
outputPathAux = "/home/bate/smart-retail-example/V1/benchmark0/spark/aux"
outputPathTest = "/home/bate/smart-retail-example/V1/benchmark0/spark/test"
upper_bound = 100
window_duration = "10 minutes"
sliding_interval = "5 minutes"

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocation):
    shutil.rmtree(checkpointLocation)

if os.path.exists(outputPath):
    shutil.rmtree(outputPath)

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocationAux):
    shutil.rmtree(checkpointLocationAux)

if os.path.exists(outputPathAux):
    shutil.rmtree(outputPathAux)

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocationTest):
    shutil.rmtree(checkpointLocationTest)

if os.path.exists(outputPathTest):
    shutil.rmtree(outputPathTest)

# Create a SparkSession
spark = SparkSession.builder \
    .appName("KafkaStructuredStreaming") \
    .getOrCreate()

#2611506, 2451124, 2574623
start = int(time.time() * 1000000)

# Read data from Kafka topic as a streaming DataFrame
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "bench0_spark") \
    .option("startingOffsets", "earliest") \
    .load()

#540325, 532382, 521513
#start = int(time.time() * 1000000)

df_s = df.selectExpr("CAST(value AS STRING)")

# Define the schema for the incoming data
schema = StructType() \
    .add("id", IntegerType()) \
    .add("number", IntegerType()) \
    .add("event_time", LongType()) \
    .add("hash", StringType()) \
    .add("flag", IntegerType())

df_f = df_s.select(from_json(col("value"), schema).alias("data")).select("data.*")

df_sum = df_f.withColumn("final_value", col("number") + col("flag"))

df_state_store = df_sum.filter("flag > 0").select("id", "event_time", "final_value")

#Df1 - Creates a column timestamp which converts the event_time into real world time
df_timestamp = df_sum.withColumn("timestamp", to_timestamp(from_unixtime("event_time")))

eventsDF = df_timestamp.withWatermark("timestamp", "5 minutes")#.withWatermark("timestamp_lat", "5 minutes")

#Df1 - Joins the two dataframes to add column price to the original dataframe
#joinedDF = eventsDF.join(df_state_store, on=["campaign_id", "event_time"], how="inner").repartition(1).dropDuplicates()

#joinedDF_watermark = joinedDF.withWatermark("timestamp", "5 minutes")

#finalDF1 = joinedDF_watermark.select("ad_id", "price", "timestamp")

finalDF1 = eventsDF.withColumn("window", window("timestamp", window_duration, sliding_interval))#.withColumn("window_lat", window("timestamp_lat", window_duration, sliding_interval))

#Df1 - Groups every purchase by ad_id and by window and calculates the profit at each window if at least a purchase was made
finalDF = finalDF1.groupBy("window", "hash").agg(avg("final_value").alias("avg_value")).repartition(1)

#Df1 - Adds columns window_start and window_end
finalDF = finalDF.withColumn("window_start", col("window.start"))
finalDF = finalDF.withColumn("window_end", col("window.end"))

#Df1 - Drops the column window and filters to show only 4 columns
finalDF = finalDF.drop("window").select("avg_value", "window_start", "window_end", "hash")

#Fazer ficheiro que faz o mesmo, mas recebe um dataframe com o state tore e na linha que define o price vai buscar a esse state store consoante o campaign id e o event time

# Calculate latency
#streamingDF = finalDF1 \
    #.withColumn("processingTime", current_timestamp())  # Record processing time
#streamingDF = streamingDF \
    #.withColumn("latency", (col("processingTime").cast("long") - col("timestamp_lat").cast("long"))).drop("window_lat", "window")

df_state_store \
    .writeStream \
    .format("csv") \
    .option("path", outputPathAux) \
    .option("header", "true") \
    .option("mode", "append") \
    .option("checkpointLocation", checkpointLocationAux) \
    .start()\
	.awaitTermination(timeout=30)

stop = int(time.time() * 1000000)
print("AQUIIIIIIIII")
print(stop - start)
time.sleep(10)
#33610403

finalDF \
    .writeStream\
	.format("csv")\
    .option("path", outputPath) \
    .option("header", "true") \
	.option("mode", "append")\
	.option("checkpointLocation", checkpointLocation)\
	.start()\
	.awaitTermination(timeout=100)