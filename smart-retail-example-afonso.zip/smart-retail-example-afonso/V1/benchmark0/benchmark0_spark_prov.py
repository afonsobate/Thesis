from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import shutil
import os

checkpointLocation = "/home/bate/smart-retail-example/V1/benchmark0/spark/prov/check"
outputPath = "/home/bate/smart-retail-example/V1/benchmark0/spark/prov"
ss_path = "/home/bate/smart-retail-example/V1/benchmark0/spark/aux"
window_duration = "10 minutes"
sliding_interval = "5 minutes"

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocation):
    shutil.rmtree(checkpointLocation)

if os.path.exists(outputPath):
    shutil.rmtree(outputPath)

schema_ss = StructType() \
    .add("id", IntegerType()) \
    .add("event_time", IntegerType()) \
    .add("final_value", IntegerType()) 

# Create a SparkSession
spark = SparkSession.builder \
    .appName("KafkaStructuredStreaming") \
    .getOrCreate()

# Read data from Kafka topic as a streaming DataFrame
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "bench0_spark_prov") \
    .option("startingOffsets", "earliest") \
    .load()

dfSS = spark.readStream \
    .format("csv") \
    .schema(schema_ss) \
    .option("header", "true") \
    .load(f"{ss_path}/*.csv")

df_s = df.selectExpr("CAST(value AS STRING)")

# Define the schema for the incoming data
schema = StructType() \
    .add("id", IntegerType()) \
    .add("number", IntegerType()) \
    .add("event_time", IntegerType()) \
    .add("hash", StringType())

df_f = df_s.select(from_json(col("value"), schema).alias("data")).select("data.*")

#Df1 - Creates a column timestamp which converts the event_time into real world time
df_timestamp = df_f.withColumn("timestamp", to_timestamp(from_unixtime("event_time")))

eventsDF = df_timestamp.withWatermark("timestamp", "5 minutes")

dfSS = dfSS.withColumn("timestamp", to_timestamp(from_unixtime("event_time"))).withWatermark("timestamp", "5 minutes")

result_df = eventsDF.join(dfSS, on=["id", "event_time", "timestamp"], how="left")

joinedDF = result_df.withColumn("number", coalesce(col("final_value"), col("number"))).drop("final_value")

finalDF1 = joinedDF.withColumn("window", window("timestamp", window_duration, sliding_interval))

#Df1 - Groups every purchase by ad_id and by window and calculates the profit at each window if at least a purchase was made
finalDF = finalDF1.groupBy("window", "hash").agg(avg("number").alias("avg_value"), sum("number").alias("sum"), count("number").alias("count"), collect_list("number").alias("numbers"), collect_list("event_time").alias("event_times"), collect_list("id").alias("ids")).repartition(1)

finalDF = finalDF.withColumn("event_times_str", concat_ws(",", "event_times")).withColumn("numbers_str", concat_ws(",", "numbers")).withColumn("ids_str", concat_ws(",", "ids"))

#Df1 - Adds columns window_start and window_end
finalDF = finalDF.withColumn("window_start", col("window.start"))
finalDF = finalDF.withColumn("window_end", col("window.end"))

#Df1 - Drops the column window and filters to show only 4 columns
finalDF = finalDF.drop("window").select("avg_value", "sum", "count", "ids_str", "event_times_str", "numbers_str", "window_start", "window_end", "hash")

#Fazer ficheiro que faz o mesmo, mas recebe um dataframe com o state tore e na linha que define o price vai buscar a esse state store consoante o campaign id e o event time

finalDF \
    .writeStream\
	.format("csv")\
    .option("path", outputPath) \
    .option("header", "true") \
	.option("mode", "append")\
	.option("checkpointLocation", checkpointLocation)\
	.start()\
	.awaitTermination(timeout=100)