import pandas as pd
import random
import time
import json
import os
import csv
import hashlib
from datetime import datetime
from time import mktime
from kafka import KafkaProducer

KAFKA_SERVER = 'localhost:9092'
NUM_LOOPS = 1000
MAX_NUMBER = 10000
BLOCK_SIZE = 65536

def hashing(filename):
    hash_value = hashlib.sha256()
    with open(filename, 'rb') as f:
        fb = f.read(BLOCK_SIZE)
        while len(fb) > 0:
            hash_value.update(fb)
            fb = f.read(BLOCK_SIZE)
    return hash_value.hexdigest()

def main():
    while True:
        try:
            producer_spark = KafkaProducer(bootstrap_servers=KAFKA_SERVER, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
            print("Connected to Kafka broker")
            break
        except:
            time.sleep(3)
            pass
    
    hashF1 = hashing("benchmark0_gen.py")
    hashF2 = hashing("benchmark0_spark.py")
    value = hashF1 + hashF2
    h = hashlib.sha256()
    h.update(value.encode())
    hash = h.hexdigest()
    
    if not os.path.exists("generated_data.csv"):
        columns = ['event_time', 'id', 'number', 'hash']
        df = pd.DataFrame(columns=columns)
        df.set_index(['id', 'event_time'], inplace=True)

        t = datetime.now()
        unix_secs = int(mktime(t.timetuple()))

        for i in range(NUM_LOOPS):
            number = random.randint(1, MAX_NUMBER)
            event_time = int(time.time() * 1000)#unix_secs+i
            print(event_time)
            if (i%100 == 0):
                flag = random.randint(1, MAX_NUMBER)
            else:
                flag = 0

            data = {
                "number": number,
                "event_time": event_time,
                "hash": hash,
                "id": i,
                "flag": flag
            }

            producer_spark.send("bench0_spark", data)

            df.loc[(i, event_time), 'number'] = number

        df.to_csv("generated_data.csv")

    else:
        with open('generated_data.csv', 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if (int(row.get("id"))%100 == 0):
                    flag = random.randint(1, MAX_NUMBER)
                else:
                    flag = 0
                data = {
                    "id": int(row.get("id")),
                    "number": int(row.get("number")),
                    "event_time": int(time.time() * 1000),#int(row.get("event_time")),
                    "hash": hash,
                    "flag": flag
                }
                producer_spark.send("bench0_spark", data)

if __name__ == "__main__":
    main()