import time
import json
import csv
import hashlib
from kafka import KafkaProducer

KAFKA_SERVER = 'localhost:9092'
BLOCK_SIZE = 65536

def hashing(filename):
    hash_value = hashlib.sha256()
    with open(filename, 'rb') as f:
        fb = f.read(BLOCK_SIZE)
        while len(fb) > 0:
            hash_value.update(fb)
            fb = f.read(BLOCK_SIZE)
    return hash_value.hexdigest()

def main():
    while True:
        try:
            producer_spark = KafkaProducer(bootstrap_servers=KAFKA_SERVER, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
            print("Connected to Kafka broker")
            break
        except:
            time.sleep(3)
            pass
    
    hashF1 = hashing("benchmark0_gen.py")
    hashF2 = hashing("benchmark0_spark.py")
    value = hashF1 + hashF2
    h = hashlib.sha256()
    h.update(value.encode())
    hash = h.hexdigest()

    with open('generated_data.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data = {
                "id": int(row.get("id")),
                "number": int(row.get("number")),
                "event_time": int(row.get("event_time")),
                "hash": hash
            }
            producer_spark.send("bench0_spark_prov", data)

if __name__ == "__main__":
    main()