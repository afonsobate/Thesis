# V1

V1 version of smart retail application.

## Features

- Detects and tracks people in a video stream.
- Detects when a person walks in and out of a zone.
  - Registers the frame number of entry and exit.
  - Saves an image of the frame.
- Divided into 4 modules:
  - `module0.py`: Hashes information   
  - `module1.py`: Detects and tracks people. Sends detections and frames to the next module.  
  - `module2.py`: Annotates bounding boxes around people. Sends annotations and detections to the next module.
  - `module3.py`: Annotates zones. Detects when a person enters and exits a zone. Saves an image of the frame and writes to a csv.

## Details

- Uses [YOLOv8](https://github.com/ultralytics/ultralytics) for object detection and tracking (built-in [BoT-SORT](https://github.com/NirAharon/BoT-SORT)).
- [Supervision](https://github.com/roboflow/supervision) for zone detection and annotations.
- [Apache Kafka](https://kafka.apache.org/) for message passing.

## Setup

Tested with Python 3.10.7.

1. Create a virtual environment:

    ```shell
    python3 -m venv .venv
    source .venv/bin/activate
    ```

2. Install dependencies:

    ```shell
    pip3 install -r requirements.txt
    ```

## Running

1. Start Kafka server.

2. Configure [config.py](config.py).

3. Set `VENV_PATH` in [start.py](start.py) and run online phase:

```shell
python3 start.py
```

Alternatively, run each module in a separate terminal.

4. For Distributed Pipeline Testing:

Run the sftp handling python files simultaneously, one in each machine:

```shell
python3 sftp_sender.py
python3 sftp_listener.py
```

5. Run offline phase:

```shell
python3 start_replay.py
```

6. Clear results

For online phase:

```shell
./clear.sh
```

For offline phase:
```shell
./clear_replay.sh
```

## Config

The config.py file contains the following variables:

- `VIDEO_PATH`: Path to the video file.

- `VIDEO_RESOLUTION_WH`: Video resolution in width and height.

- `VIDEO_FPS`: Video framerate.

- `KAFKA_SERVER`: Kafka server address.

- `MODEL`: One of the following (see [YOLOv8 Models](https://github.com/ultralytics/ultralytics?ref=roboflow-blog#models)):
  - `yolov8n.pt`
  - `yolov8s.pt`
  - `yolov8m.pt`
  - `yolov8l.pt`
  - `yolov8x.pt`
