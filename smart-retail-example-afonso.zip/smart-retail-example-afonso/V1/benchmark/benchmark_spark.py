from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import shutil
import os
import time

checkpointLocation = "/home/bate/smart-retail-example/V1/benchmark/spark/output/check"
checkpointLocationAux = "/home/bate/smart-retail-example/V1/benchmark/spark/aux/check"
checkpointLocationTest = "/home/bate/smart-retail-example/V1/benchmark/spark/test/check"
outputPath = "/home/bate/smart-retail-example/V1/benchmark/spark/output"
outputPathAux = "/home/bate/smart-retail-example/V1/benchmark/spark/aux"
outputPathTest = "/home/bate/smart-retail-example/V1/benchmark/spark/test"
upper_bound = 100
window_duration = "10 minutes"
sliding_interval = "5 minutes"

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocation):
    shutil.rmtree(checkpointLocation)

if os.path.exists(outputPath):
    shutil.rmtree(outputPath)

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocationAux):
    shutil.rmtree(checkpointLocationAux)

if os.path.exists(outputPathAux):
    shutil.rmtree(outputPathAux)

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocationTest):
    shutil.rmtree(checkpointLocationTest)

if os.path.exists(outputPathTest):
    shutil.rmtree(outputPathTest)

# Create a SparkSession
spark = SparkSession.builder \
    .appName("KafkaStructuredStreaming") \
    .getOrCreate()

#2646287, 2604280, 2505975, 2511284, 2610015
start = int(time.time() * 1000000)

# Read data from Kafka topic as a streaming DataFrame
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "bench_spark") \
    .option("startingOffsets", "earliest") \
    .load()

#start = int(time.time() * 1000000)
#678433, 693708, 710297, 641119, 609336

df_s = df.selectExpr("CAST(value AS STRING)")

# Define the schema for the incoming data
schema = StructType() \
    .add("user_id", IntegerType()) \
    .add("page_id", IntegerType()) \
    .add("ad_id", IntegerType()) \
    .add("ad_type", StringType()) \
    .add("event_type", StringType()) \
    .add("event_time", LongType()) \
    .add("hash", StringType()) \
    .add("id", IntegerType()) \
    .add("price", FloatType())

df_f = df_s.select(from_json(col("value"), schema).alias("data")).select("data.*")

#df_aux = df_f.withColumn("incoming_time", current_timestamp().cast("long") * 1000000)

#Df1 - Filters to show only events of the type "purchase"
df_filter = df_f.filter(col("event_type") == "purchase")

#Df1 - Filters to show only the ad_id, event_time and hash
df_projection = df_filter.select("ad_id", "event_time", "hash", "price")

df_campaign = df_projection.withColumn("campaign_id", when(col("ad_id") % 10 == 0, 10).otherwise(col("ad_id") % 10))

df_state_store = df_campaign.select("campaign_id", "event_time", "price")

#Df1 - Creates a column timestamp which converts the event_time into real world time
df_timestamp = df_campaign.withColumn("timestamp", to_timestamp(from_unixtime("event_time")))

eventsDF = df_timestamp.withWatermark("timestamp", "5 minutes").drop("price")

#df_camp_no_dup = df_campaign.dropDuplicates()

#Df1 - Joins the two dataframes to add column price to the original dataframe
joinedDF = eventsDF.join(df_state_store, on=["campaign_id", "event_time"], how="inner").repartition(1).dropDuplicates()

#joinedDF_watermark = joinedDF.withWatermark("timestamp", "5 minutes")

#finalDF1 = joinedDF_watermark.select("ad_id", "price", "timestamp")

finalDF1 = joinedDF.withColumn("window", window("timestamp", window_duration, sliding_interval))

#Df1 - Groups every purchase by ad_id and by window and calculates the profit at each window if at least a purchase was made
finalDF = finalDF1.groupBy("window", "campaign_id", "hash").agg(sum("price").alias("total_profit")).repartition(1)

#Df1 - Adds columns window_start and window_end
finalDF = finalDF.withColumn("window_start", col("window.start"))
finalDF = finalDF.withColumn("window_end", col("window.end"))

#Df1 - Drops the column window and filters to show only 4 columns
finalDF = finalDF.drop("window").select("campaign_id", "total_profit", "window_start", "window_end", "hash")

#lat_df = df_aux.withColumn("processing_time", current_timestamp().cast("long") * 1000000).withColumn("latencySpark", (col("processing_time") - col("incoming_time"))).withColumn("latency", (col("processing_time") - col("event_time"))).select("id", "processing_time", "event_time", "incoming_time", "latency", "latencySpark")

#Fazer ficheiro que faz o mesmo, mas recebe um dataframe com o state tore e na linha que define o price vai buscar a esse state store consoante o campaign id e o event time

#lat_df \
    #.writeStream\
	#.format("csv")\
    #.option("path", outputPathTest) \
    #.option("header", "true") \
	#.option("mode", "append")\
	#.option("checkpointLocation", checkpointLocationTest)\
	#.start()\
	#.awaitTermination(timeout=30)

df_state_store \
    .writeStream \
    .format("csv") \
    .option("path", outputPathAux) \
    .option("header", "true") \
    .option("mode", "append") \
    .option("checkpointLocation", checkpointLocationAux) \
    .start()\
	.awaitTermination(timeout=30)

stop = int(time.time() * 1000000)
print("AQUIIIIIIIII")
print(stop - start)
time.sleep(10)
#33122704

finalDF \
    .writeStream\
	.format("csv")\
    .option("path", outputPath) \
    .option("header", "true") \
	.option("mode", "append")\
	.option("checkpointLocation", checkpointLocation)\
	.start()\
	.awaitTermination(timeout=100)
