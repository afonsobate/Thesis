from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import shutil
import os

checkpointLocation = "/home/bate/smart-retail-example/V1/benchmark/spark/prov/check"
outputPath = "/home/bate/smart-retail-example/V1/benchmark/spark/prov"
ss_path = "/home/bate/smart-retail-example/V1/benchmark/spark/aux"
window_duration = "10 minutes"
sliding_interval = "5 minutes"

# Delete the checkpoint directory if it exists
if os.path.exists(checkpointLocation):
    shutil.rmtree(checkpointLocation)

if os.path.exists(outputPath):
    shutil.rmtree(outputPath)

schema_ss = StructType() \
    .add("campaign_id", IntegerType()) \
    .add("event_time", IntegerType()) \
    .add("price", FloatType()) 

# Create a SparkSession
spark = SparkSession.builder \
    .appName("KafkaStructuredStreaming") \
    .getOrCreate()

# Read data from Kafka topic as a streaming DataFrame
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "bench_spark_prov") \
    .option("startingOffsets", "earliest") \
    .load()

dfSS = spark.readStream \
    .format("csv") \
    .schema(schema_ss) \
    .option("header", "true") \
    .load(f"{ss_path}/*.csv")

df_s = df.selectExpr("CAST(value AS STRING)")

# Define the schema for the incoming data
schema = StructType() \
    .add("user_id", IntegerType()) \
    .add("page_id", IntegerType()) \
    .add("ad_id", IntegerType()) \
    .add("ad_type", StringType()) \
    .add("event_type", StringType()) \
    .add("event_time", IntegerType()) \
    .add("hash", StringType())

df_f = df_s.select(from_json(col("value"), schema).alias("data")).select("data.*")

#Df1 - Filters to show only events of the type "purchase"
df_filter = df_f.filter(col("event_type") == "purchase")

#Df1 - Filters to show only the ad_id, event_time and hash
df_projection = df_filter.select("ad_id", "event_time", "hash")

df_campaign = df_projection.withColumn("campaign_id", when(col("ad_id") % 10 == 0, 10).otherwise(col("ad_id") % 10))

#Df1 - Creates a column timestamp which converts the event_time into real world time
df_timestamp = df_campaign.withColumn("timestamp", to_timestamp(from_unixtime("event_time")))

eventsDF = df_timestamp.withWatermark("timestamp", "5 minutes")

#Df2 - Sets a random price to the campaign at each purchase and drops the column hash
#df_campaign_price = df_campaign.withColumn("price", rand() * upper_bound).drop("hash")

#Df2 - State store with the price of every campaign through time
#df_state_store = df_campaign_price.select("campaign_id", "event_time", "price")

#df_camp_no_dup = df_campaign.dropDuplicates()

#Df1 - Joins the two dataframes to add column price to the original dataframe
joinedDF = eventsDF.join(dfSS, on=["campaign_id", "event_time"], how="inner").repartition(1).dropDuplicates()

#joinedDF_watermark = joinedDF.withWatermark("timestamp", "5 minutes")

#finalDF1 = joinedDF_watermark.select("ad_id", "price", "timestamp")

finalDF1 = joinedDF.withColumn("window", window("timestamp", window_duration, sliding_interval))

#Df1 - Groups every purchase by ad_id and by window and calculates the profit at each window if at least a purchase was made
finalDF = finalDF1.groupBy("window", "ad_id", "hash", "campaign_id").agg(collect_list("price").alias("prices"), collect_list("event_time").alias("event_times")).repartition(1)

finalDF = finalDF.withColumn("event_times_str", concat_ws(",", "event_times")).withColumn("prices_str", concat_ws(",", "prices"))

#Df1 - Adds columns window_start and window_end
finalDF = finalDF.withColumn("window_start", col("window.start"))
finalDF = finalDF.withColumn("window_end", col("window.end"))

#Df1 - Drops the column window and filters to show only 4 columns
finalDF = finalDF.drop("window").select("ad_id", "campaign_id", "event_times_str", "prices_str", "window_start", "window_end", "hash")

#Fazer ficheiro que faz o mesmo, mas recebe um dataframe com o state tore e na linha que define o price vai buscar a esse state store consoante o campaign id e o event time

finalDF \
    .writeStream\
	.format("csv")\
    .option("path", outputPath) \
    .option("header", "true") \
	.option("mode", "append")\
	.option("checkpointLocation", checkpointLocation)\
	.start()\
	.awaitTermination(timeout=100)