import pandas as pd
import random
import time
import json
import os
import csv
import hashlib
from datetime import datetime
from time import mktime
from kafka import KafkaProducer

KAFKA_SERVER = 'localhost:9092'
NUM_LOOPS = 1000
MAX_USER_ID = 200
MAX_PAGE_ID = 50
MAX_AD_ID = 100
MAX_CAMPAIGN_ID = 10
AD_TYPE = ("banner", "modal", "sponsored-search", "mail", "mobile")
EVENT_TYPE = ("view", "click", "purchase")
BLOCK_SIZE = 65536

def hashing(filename):
    hash_value = hashlib.sha256()
    with open(filename, 'rb') as f:
        fb = f.read(BLOCK_SIZE)
        while len(fb) > 0:
            hash_value.update(fb)
            fb = f.read(BLOCK_SIZE)
    return hash_value.hexdigest()

def main():
    while True:
        try:
            producer_spark = KafkaProducer(bootstrap_servers=KAFKA_SERVER, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
            print("Connected to Kafka broker")
            break
        except:
            time.sleep(3)
            pass
    
    hashF1 = hashing("benchmark_gen.py")
    hashF2 = hashing("benchmark_spark.py")
    value = hashF1 + hashF2
    h = hashlib.sha256()
    h.update(value.encode())
    hash = h.hexdigest()
    
    if not os.path.exists("generated_data.csv"):
        columns = ['user_id', 'page_id', 'ad_id', 'ad_type', 'event_type', 'event_time', 'id']
        df = pd.DataFrame(columns=columns)
        df.set_index(['user_id', 'event_time'], inplace=True)

        t = datetime.now()
        unix_secs = int(mktime(t.timetuple()))

        for i in range(NUM_LOOPS):
            user_id = random.randint(1, MAX_USER_ID)
            page_id = random.randint(1, MAX_PAGE_ID)
            ad_id = random.randint(1, MAX_AD_ID)
            ad_type = AD_TYPE[random.randint(0, 4)]
            event_type = EVENT_TYPE[random.randint(0, 2)]
            event_time = int(time.time() * 1000000)

            data = {
                "user_id": user_id,
                "page_id": page_id,
                "ad_id": ad_id,
                "ad_type": ad_type,
                "event_type": event_type,
                "event_time": event_time,
                "hash": hash,
                "id": i,
                "price": random.random() * MAX_AD_ID
            }

            producer_spark.send("bench_spark", data)

            df.loc[(user_id, event_time), 'page_id'] = page_id
            df.loc[(user_id, event_time), 'ad_id'] = ad_id
            df.loc[(user_id, event_time), 'ad_type'] = ad_type
            df.loc[(user_id, event_time), 'event_type'] = event_type
            df.loc[(user_id, event_time), 'id'] = i

        df.to_csv("generated_data.csv")

    else:
        with open('generated_data.csv', 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                data = {
                    "user_id": int(row.get("user_id")),
                    "page_id": int(row.get("page_id")),
                    "ad_id": int(row.get("ad_id")),
                    "ad_type": str(row.get("ad_type")),
                    "event_type": str(row.get("event_type")),
                    "event_time": int(time.time() * 1000000),#int(row.get("event_time")),
                    "hash": hash,
                    "id": int(row.get("id")),
                    "price": random.random() * MAX_AD_ID
                }
                producer_spark.send("bench_spark", data)

if __name__ == "__main__":
    main()