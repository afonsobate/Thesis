#!/bin/bash
rm -rf output/frames/*.jpg
rm -rf output/*.csv
rm -rf output/videos/*.mp4
rm -rf output/state_store/*.json
rm -rf output/state_store/*.torchscript
rm -rf output/state_store/*.pkl
rm -rf provenance/*
rm -rf *.torchscript