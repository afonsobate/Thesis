#!/bin/bash
rm -rf replay/*