#!/bin/bash
rm -rf provenance/frames/*/*.jpg
rm -rf provenance/*.csv
rm -rf provenance/*.mp4